
struct BinaryTreeNode {
  int data;
  struct BinaryTreeNode *left;
  struct BinaryTreeNode *right;
};

typedef struct BinaryTreeNode BinaryTree;
typedef struct BinaryTreeNode BinaryTreeNode;
typedef BinaryTreeNode* TreeNodePtr;
